from django.contrib import admin

from services.models import Service

# Register your models here.

admin.site.register(Service)

