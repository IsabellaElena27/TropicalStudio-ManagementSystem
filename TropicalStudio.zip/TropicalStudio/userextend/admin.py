from django.contrib import admin
from django.contrib.auth.models import Permission

# Register your models here.
admin.site.register(Permission)
